export const Font={
    FontBold:'Inter-Bold',
    FontExtraBold:'Inter-ExtraBold',
    FontLight:'Inter-Light',
    FontMedium:'Inter-Medium',
    FontRegular:'Inter-Regular',
    FontSemiBold:'Inter-SemiBold',
    FontBlack:'Inter-Black',
    FontExtraLight:'Inter-ExtraLight',
    FontThin:'Inter-Thin',
}