export const SuggestedProducts = [
    {
      id: 1,
      thumbnail: require("../Assets/Images/Nike-Air-Max-97-Air-Force.png"),
      title: "Nike Air Max",
    },
    {
      id: 2,
      thumbnail: require("../Assets/Images/Nike-Air-Max-Sneakers-red-white.png"),
      title: "Sneakers",
    },
    {
      id: 3,
      thumbnail: require("../Assets/Images/Nike-Shoe-Running.png"),
      title: "Running Shoe",
    },
  ];